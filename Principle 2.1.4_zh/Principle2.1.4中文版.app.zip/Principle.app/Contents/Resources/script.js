/*
 
 Hello! You found our import file.
 
 This file is a nightmare to maintain because we keep having to add workarounds to Sketch's bugs. 
 If you're looking at this file to make your own plug in, you've been warned. 
 If you work at sketch and you're looking at this file, look what you've made us do.
 
 */

var doc, export_directory,
export_scale_factor = 1,
assetNumber = 1,
MSSymbolInstanceClassAvalible = (NSClassFromString(@"MSSymbolInstance") != nil),
MSTextLayerClassAvalible = (NSClassFromString(@"MSTextLayer") != nil),
BlurAvalible = [MSStyle instancesRespondToSelector:NSSelectorFromString("blurGeneric")];

function dump(obj){
    log("######################################")
    log("## Dumping object " + obj )
    log("## obj class is: " + [obj className])
    log("######################################")
    
    
    log("obj class hierarchy:")
    var theclass = [obj class];
    
    while (theclass != nil) {
        log(theclass);
        theclass = [theclass superclass];
    }
    
    log("obj.properties:")
    log([obj class].mocha().properties())
    log("obj.propertiesWithAncestors:")
    log([obj class].mocha().propertiesWithAncestors())
    
    log("obj.classMethods:")
    log([obj class].mocha().classMethods())
    log("obj.classMethodsWithAncestors:")
    log([obj class].mocha().classMethodsWithAncestors())
    
    log("obj.instanceMethods:")
    log([obj class].mocha().instanceMethods())
    log("obj.instanceMethodsWithAncestors:")
    log([obj class].mocha().instanceMethodsWithAncestors())
    
    log("obj.protocols:")
    log([obj class].mocha().protocols())
    log("obj.protocolsWithAncestors:")
    log([obj class].mocha().protocolsWithAncestors())
    
    log("obj.treeAsDictionary():")
    log(obj.treeAsDictionary())
}

function dog(m) {
//    log(m)
}

function recursiveLog(layer, depth) {
    var str=""
    for (var j=depth;j>0;j--) {
        str+="-";
    }
    log(str+""+[layer name]);
    
    var subs = get_sublayers(layer)
    for (var i =0;i < [subs count]; i++) {
        recursiveLog([subs objectAtIndex:i], depth+1);
    }
}

function sublayerDepth(layer) {
    if (!layer) {
        return 0;
    }
    
    var sublayers = get_sublayers(layer);
    if (!sublayers || sublayers.length === 0) {
        return 0;
    }
    
    return 1+sublayerDepth(sublayers[0]);
}

function exportDirect(exportPath, assetScale) { // Called Externally
    export_scale_factor = assetScale;
    
    dog("========================= Principle Export log =========================");
    doc = [[[NSApplication sharedApplication] orderedDocuments] firstObject];
    [doc showMessage:"导出到 Principle 中..."];
    
    export_directory = exportPath;
    [[NSFileManager defaultManager] createDirectoryAtPath:export_directory withIntermediateDirectories:true attributes:null error:null];
    
    var layers = [[doc currentPage] layers];
    var artboards = flatMap(layers, function(layer) {
                            var canExport = [layer isMemberOfClass:[MSArtboardGroup class]] || isSymbolMaster(layer);
                            return canExport ? layer: null;
                            });
    var index = 1;
    var principleNotificationName = "com.hoopersoftware.principle.import.progressupdate";
    function artboardToMetaData(layer) {
        [doc showMessage:"Exporting Artboard '"+[layer name]+"' to Principle..."];
        var progressInfo = {imported: index, total: [artboards count], artboardName: [layer name]};
        [[NSDistributedNotificationCenter defaultCenter] postNotificationName:principleNotificationName object:null userInfo:progressInfo deliverImmediately:true];
        index+=1;
        return process_layer(layer, layer, "")
    }
    
    var layers_metadata = flatMap(artboards, artboardToMetaData);
    
    // Write settings
    var settings = [[NSMutableDictionary alloc] init]; // for data.json file
    [settings setValue:export_scale_factor forKey:@"scale"];
    [settings setValue:layers_metadata forKey:@"layers"];
    log(settings);
    var scaleJSON = [NSJSONSerialization dataWithJSONObject:settings options:NSJSONWritingPrettyPrinted error:nil];
    scaleJSON = [[NSString alloc] initWithData:scaleJSON encoding:NSUTF8StringEncoding];
    var settings_filepath = export_directory + "/data.json";
    dog("Writing data.json to:" +settings_filepath+ "with contents: " + scaleJSON);
    
    [scaleJSON writeToFile:settings_filepath atomically:true encoding:NSUTF8StringEncoding error:null];
    
    [doc showMessage:"导出到 Principle 完成"];
}

function process_layer(original_layer, layer, uuidStack) {
    
    var shouldIgnoreLayer = ([layer name].slice(-1) == "-" || [layer isMemberOfClass: [MSSliceLayer class]] || ![layer isVisible]);
    if (shouldIgnoreLayer) { return; }
    
    var remove_after_process = false;
    var needsToRasterize = false;
    var original_sublayers = get_sublayers(original_layer);
 
    var original_layer_id = (original_layer ? [original_layer objectID] : null);
    var layer_is_symbol = isSymbolInstance(layer);
    
    if (layer_is_symbol) {
        var copiedInstance = [[layer duplicate] detachByReplacingWithGroup];
        if (!copiedInstance){
            // layer is a symbol with no sublayers
            // sketch has a bug that causes no layer to get created, so we have to rasterize the instance
            dog("rasterizing '"+[layer name]+"': because copying symbol resulted in no layer");
            needsToRasterize = true;
        } else {
            remove_after_process = true;
            layer = copiedInstance;
            
            if (sublayerDepth(layer) != sublayerDepth(original_layer)) { // this is a workaround for sketch 39 "helpfully" removeing double-grouped instances
                original_layer = [original_sublayers firstObject];
                original_sublayers = get_sublayers(original_layer);
                
            }
        }
    }
    
    if (!layer) {
        return;
    }
    
    var imagePath, sublayers, layers_holder, sub, newUUIDStack = uuidStack;
    
    var skipBorderRasterization = false;
    var style = [layer style];
    var frame = [layer frame];
    

    
    var layer_data = {
    x: [frame x],
    y: [frame y],
    w: [frame width],
    h: [frame height],
    name: [layer name].replace("*","").replace("@2x","").replace("@3x","").replace("@1x",""),
    opacity: [[style contextSettings] opacity],
    };
    
    if ([layer isLocked]) {
        layer_data.locked = true;
    }
    
    var sublayers = get_sublayers(layer);
    
    if (original_layer_id) {
        layer_data["id"] = (uuidStack + original_layer_id);

        if (layer_is_symbol) {
            newUUIDStack = layer_data["id"] + "-";
        }
    }
    
    function generateData() {
        function enabled(stylePartCollection) {
            return filter(getAsArray(stylePartCollection), function(el) {return [el isEnabled]});
        }
        
        var should_flatten_layer = ([layer name].slice(-1) == "*");
        if (should_flatten_layer) {
            dog("rasterizing '"+[layer name]+"': because *");
            return true;
        }
        
        if (BlurAvalible && [[style blurGeneric] isEnabled]) {
            dog("rasterizing '"+[layer name]+"': blur enabled");
            return true;
        }
        
        var enabledShadows = enabled([style shadows]);
        var enabledBorders = enabled([style borders]);
        if (enabledBorders.length > 1 || enabledShadows.length > 1) {
            dog("rasterizing "+[layer name]+": enabled count");
            return true;
        }
        
        for (var j=0;j<[sublayers count];j++) {
            if ([[sublayers objectAtIndex:j] isMasked]) {
                dog("rasterizing "+[layer name]+": contains mask");
                return true; // flatten groups containing a mask
            }
        }
        
        function checkBorderType() {
            
            if ([layer isMemberOfClass:[MSArtboardGroup class]]) { // Workaround for sketch 39 bug: all artboards had an invisible border
                return false;
            }
            
            if (enabledBorders.length == 0) {
                return false;
            }
            
            if ([style startDecorationType] != 0 || [style endDecorationType] != 0) {
                dog([layer name]+" has start or end decoration");
                return true;
            }
            
            if ([[style borderOptions] hasDashPattern]) {
                dog([layer name]+" has border dash pattern");
                return true;
            }
            
            if (enabledBorders.length == 1) {
                var firstBorder = enabledBorders[0];
                skipBorderRasterization = ([firstBorder position] == 1 && [firstBorder fillType] == 0);
                if (skipBorderRasterization) { // border is inside & solid
                    layer_data.border = jsonObjectForBorder(firstBorder);
                }
            }
            
            return !skipBorderRasterization;
        }
        
        var enabledFills = enabled([style fills]);
        
        if ([layer isMemberOfClass:[MSArtboardGroup class]] || [layer isMemberOfClass:[MSLayerGroup class]] || isSymbolMaster(layer)) {
            if ([layer isMemberOfClass:[MSArtboardGroup class]] || isSymbolMaster(layer)) {
                if ([layer hasBackgroundColor]) {
                    layer_data.fillColor = jsonObjectForColor([layer backgroundColorGeneric]);
                    layer_data.fillColor.a = 1;
                } else {
                    layer_data.fillColor = {r:1,g:1,b:1,a:1};
                }
            }
        } else if ([layer isMemberOfClass:[MSShapeGroup class]]) {
            var pathLayers = [layer layers];
            if ([pathLayers count] != 1) {
                dog("'"+[layer name]+"' rasterizing b/c non 1 path count");
                return true;
            }
            
            var shape = [pathLayers firstObject];
            
            if ([shape respondsToSelector:NSSelectorFromString("edited")] && [shape edited]) {
                dog("rasterizing '"+[layer name]+"': edited");
                return true;
            }
            
            if ([shape isMemberOfClass:[MSRectangleShape class]]) {
                //this is a workaround for the radius syntax change in Sketch 42 - '36781' is the build bumber for Sketch 42
                var version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"];
                var radiusTextDivider = ([version integerValue] >= 36781) ? ";" : "/";
                
                if ([[shape cornerRadiusString] containsString: radiusTextDivider]) {
                    dog("rasterizing  '"+[layer name]+"': multiple radius");
                    return true;
                } else {
                    layer_data.radius = [shape cornerRadiusFloat];
                }
            } else if ([shape isMemberOfClass:[MSOvalShape class]]) {
                var frame = [shape frame]
                if (Math.abs([frame width] - [frame height]) < 1) {
                    layer_data.radius = [frame width]/2;
                } else {
                    dog([layer name]+"' rasterizing b/c non square oval: " + frame);
                    return true;
                }
            } else {
                dog("rasterizing '"+[layer name]+"': class: "+[layer class]);
                return true;
            }
            
            if (enabledFills.length == 1) {
                var firstFill = enabledFills[0];
                if ([firstFill fillType] == 0) {
                    layer_data.fillColor = jsonObjectForColor([firstFill colorGeneric]);
                } else {
                    dog("rasterizing '"+[layer name]+"': fill type");
                    checkBorderType();
                    return true;
                }
            }
        } else if (layer_is_symbol) {
            // do nothing?
        } else {
            dog("rasterizing '"+[layer name]+"': layer type: "+[layer class]);
            return true;
        }
        
        if (enabledShadows.length == 1) {
            var shadowInfo = enabledShadows[0];
            layer_data.shadow = {
            color: jsonObjectForColor([shadowInfo color]),
            x:[shadowInfo offsetX],
            y:[shadowInfo offsetY],
            blur:[shadowInfo blurRadius]
            }
        }
        
        var needsToRasterizeBorder = checkBorderType();
        if (needsToRasterizeBorder) {
            dog("rasterizing '"+[layer name]+"': border type");
            return true;
        }
        
        if (enabledFills.length > 1 || (enabled([style innerShadows]).length > 0)) {
            dog("rasterizing '"+[layer name]+"': enabled fills or inner shadows count");
            return true;
        }
        
        return false;
    }
    
    needsToRasterize = generateData()
    
    if (needsToRasterize) {
        log("needs to rasterize "+[layer name]);
        layer_data.fillColor = {r:1,g:1,b:1,a:0};
        if (!skipBorderRasterization) {
            delete layer_data.border;
        }
        
//        var rect = [MSSliceTrimming trimmedRectForSlice:layer];
//        layer_data.w = rect.size.width;
//        layer_data.h = rect.size.height;
//        layer_data.x = rect.origin.x;
//        layer_data.y = rect.origin.y;
//        layer_data.image = export_layer(layer, skipBorderRasterization);
        
        //influenceRectForFrame returns wrong frame when shapes intersect and opacity is zero, this is a temporary fix
        var originalOpacity = [[[layer style] contextSettings] opacity];
        [[[layer style] contextSettings] setOpacity:1];
        
        var influenceFrame = [layer influenceRectForFrame];
        var absInfluenceRect = [layer absoluteInfluenceRect];
        
        [[[layer style] contextSettings] setOpacity:originalOpacity];

        layer_data.x = influenceFrame.origin.x + absInfluenceRect.origin.x % 1;
        layer_data.y = influenceFrame.origin.y + absInfluenceRect.origin.y % 1;
        layer_data.image = export_layer(layer, skipBorderRasterization);
        
        var image = [[NSImage alloc] initWithContentsOfFile:layer_data.image];
        if (image != null && export_scale_factor != 0) {
            layer_data.w = [image size].width / export_scale_factor;
            layer_data.h = [image size].height / export_scale_factor;
        } else {
            layer_data.w = influenceFrame.size.width;
            layer_data.h = influenceFrame.size.height;
        }
        
    } else {
        if ([layer rotation] != 0) {
            layer_data.angle = 360-[layer rotation];
        }
        
        if ([sublayers count] != [original_sublayers count]) {
            original_sublayers = nil;
            log("sublayers don't match:"+[layer name]+" : "+[original_layer name]);
        }
        
        layers_holder = [];
        for (var i = 0; i < [sublayers count]; i++) {
            var original_sublayer = original_sublayers ? [original_sublayers objectAtIndex:i] : null;
            layers_holder.pushNonNull(process_layer(original_sublayer, [sublayers objectAtIndex:i], newUUIDStack))
        }
        
        if (layers_holder.length > 0) {
            layer_data.layers = layers_holder;
        }
    }
    
    if (remove_after_process) {
        [layer removeFromParent];
    }
    
    return layer_data;
}

function get_sublayers(layer) {
    if (!layer) {
        return [];
    }

    
    if ([layer isMemberOfClass:[MSLayerGroup class]] || [layer isMemberOfClass:[MSArtboardGroup class]]) {
        return [layer layers];
    } else if (isSymbolInstance(layer)) {
        return getAsArray([[layer symbolMaster] layers]);
    } else if (isSymbolMaster(layer)) {
        return getAsArray([layer layers]);
    }
    
    return [];
}

function isSymbolMaster(layer) {
    return MSSymbolInstanceClassAvalible && [layer isMemberOfClass:[MSSymbolMaster class]];
}

function isSymbolInstance(layer) {
    return MSSymbolInstanceClassAvalible && [layer isMemberOfClass:[MSSymbolInstance class]];
}

function export_layer(layer, skipBorderRasterization) {
    var path_to_file = export_directory + "/assets/" + assetNumber + ".png";
    assetNumber++;
    
    var layer_to_render = layer;
    
    var style = [layer style];
    var layerIsBlurred = (BlurAvalible && [[style blurGeneric] isEnabled]);
    var removeAfterRender = !layerIsBlurred;
    
    if (removeAfterRender) {
        layer_to_render = [layer duplicate];
        [layer_to_render removeFromParent];
        [layer_to_render setShouldBreakMaskChain:true]; // fix masks outside of artboards from completely hiding the rendered layer
        [[doc currentPage] addLayers: [layer_to_render]];
        [layer_to_render setIsVisible:true];
        
        var frame = [layer_to_render frame];
        [frame setX: -999999];
        [frame setY: -999999];
    }
    
    var borders = getAsArray([[layer_to_render style] borders]);
    
    var bordersToEnable = [];
    if (skipBorderRasterization) {
        for (var i = 0; i < [borders count]; i++) {
            var part = [borders objectAtIndex:i];
            if ([part isEnabled]) {
                bordersToEnable.push(part);
                [part setIsEnabled:false];
            }
        }
    }
    
    var originalOpacity = [[style contextSettings] opacity];
    [[[layer_to_render style] contextSettings] setOpacity:1];
    
    var rect = [layer_to_render absoluteInfluenceRect];
    
    // workaround for sketch 39 making fixed width layers really wide.
    if (MSTextLayerClassAvalible && [layer_to_render isMemberOfClass: [MSTextLayer class]]) {
        if ([layer_to_render textContainerSize].width < rect.size.width) {
            rect.size.width = [layer_to_render rect].size.width;
        }
    }
    
    var exportRequest;
    if ([[MSExportRequest class] respondsToSelector:NSSelectorFromString("requestWithRect:scale:")]) {
        exportRequest = [MSExportRequest requestWithRect:rect scale:export_scale_factor];
    } else {
        exportRequest = MSExportRequest.new();
        exportRequest.rect = rect;
        exportRequest.scale = export_scale_factor;
    }
    
    exportRequest.shouldTrim = false;
    
    // sketch 41 broke configureForLayer, so we have to use the new version of the API
    if (exportRequest.respondsToSelector(NSSelectorFromString("configureForLayerAncestry:layerOptions:includedIDs:"))) {
        var ancestry = [MSImmutableLayerAncestry ancestryWithMSLayer:layer_to_render];
        [exportRequest configureForLayerAncestry:ancestry layerOptions:nil includedIDs:nil];
    } else {
        exportRequest.configureForLayer(layer_to_render)
    }
    exportRequest.includeArtboardBackground = ![[layer class] isMemberOfClass:[MSArtboardGroup class]];
    [doc saveExportRequest:exportRequest toFile:path_to_file];
    
    if (removeAfterRender) {
        [layer_to_render removeFromParent];
    } else {
        [[[layer_to_render style] contextSettings] setOpacity:originalOpacity];
        
        if (skipBorderRasterization) {
            for (var i = 0; i < [bordersToEnable count]; i++) {
                [[bordersToEnable objectAtIndex:i] setIsEnabled:true];
            }
        }
    }
    
    return path_to_file;
}

function jsonObjectForBorder(border) {
    return {
    color: jsonObjectForColor([border colorGeneric]),
    width: [border thickness]
    };
}

function jsonObjectForColor(color) {
    return {
    r: [color red],
    g: [color green],
    b: [color blue],
    a: [color alpha]
    };
}

function getAsArray(obj) { // Sketch 39 removed the -array method form a bunch of stuff, this is a workaround
    if ([obj respondsToSelector:NSSelectorFromString("array")]) {
        obj = [obj array];
    }
    return obj;
}

function filter(array, filterFunction) {
    var result = []
    for (var i =0; i < array.count(); i++) {
        var element = array.objectAtIndex(i);
        if (filterFunction(element)) {
            result.push(element)
        }
    }
    return result;
}

function flatMap(array, mapFunction) {
    var result = []
    for (var i =0; i < array.count(); i++) {
        var element = array.objectAtIndex(i);
        result.pushNonNull(mapFunction(element))
    }
    return result;
}

Array.prototype.pushNonNull = function(obj) {if(obj !== null && obj !== undefined){this.push(obj);}}
Array.prototype.count = function() {return this.length;}
Array.prototype.objectAtIndex = function(idx) {return this[idx];};
